<?php
// Initialize the session
session_start();
 
// Redirect user to enter password page
header("location: auth.php");



?>

